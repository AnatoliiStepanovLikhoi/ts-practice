import * as validators from "01-validators"; // імпорт всього вмісту модуля в змінну validators

const ccValidtor = new validators.CreditCardValidator();
const urlValidtor = new validators.UrlValidator();